﻿/*
  Declare
*/

DECLARE @PC  TABLE 
   (
    id int not null, 
	cpu varchar(255) not null,
	memory int not null,
	hdd int not null
   ) 

Declare @Departaments table
 (
     id int not null, 
	 Name varchar(255) not null
 )

Declare @Users table
 (
     id int not null, 
	 UserName varchar(255) not null,
	 Salary int not null, 
	 DepartamentId int not null, 
	 PCId int not null
 )

 /*
 --Syntax limitation, impossible to table variables, commented out

ALTER TABLE @Users    
ADD CONSTRAINT FK_PCId FOREIGN KEY (PCId)     
    REFERENCES @PC (PCId) 

ALTER TABLE @Users    
ADD CONSTRAINT FK_DepartamentId FOREIGN KEY (DepartamentId)     
    REFERENCES @Departaments (DepartamentId) 
*/

/*
 Init
*/

INSERT INTO @PC 	VALUES 
	(1,'Intel P4',400,400),
	(2,'Intel P5',500,500),
	(3,'Intel P6',600,600)

INSERT INTO @Users 	VALUES 
	(1,'User 1',100,1,1),
	(2,'User 2',200,1,2),
	(3,'User 3',301,2,3)

INSERT INTO @Departaments 	VALUES 
	(1,'Departaments 1'),
	(2,'Departaments 2')

/*
  Check
*/

SELECT * FROM @PC
SELECT * FROM @Users
SELECT * FROM @Departaments

/*
1.1.	Написать запрос, который сформирует выборку тактовых частот процессоров  компьютеров (cpu) у которых объем памяти равен 3000Mb. 
*/
 select cpu from @pc where memory = 400

/*
1.2.	Написать запрос, который сформирует выборку пользователей,
 компьютер  которых содержит жесткий диск объемом > 500Gb. 
 Выборка так же должна содержать отдел, в котором работает пользователь. 
*/

select u.* from @users u join @pc p on u.PCId=p.id
 where p.hdd > 500

/*
1.3.	Написать запрос, который сформирует выборку отделов и количества сотрудников, работающих в этих отделах.  
Вывести наименование отдела и кол. сотрудников данного отдела.
*/

select d.Name, count(*) UsersCount from @Departaments d join @Users u on d.id = u.id
 group by d.Name

/*
1.4.	Написать запрос, который сформирует выборку отделов и количество сотрудников, у которых сумма оклада больше 100 тыс. руб.
 Вывести наименование отдела и кол. сотрудников данного отдела и сумму окладов сотрудников.
*/

select d.Name, count(*) UsersCount, sum (u.Salary) UsersSalarySum
  from @Departaments d join @Users u on d.id = u.id
 where u.Salary > 100
 group by d.Name


/*
1.5.	Написать запрос, который сформирует выборку компьютеров отдела, у сотрудников которого максимальная сумма окладов.
*/

;with MaxSalaryByDepartments as
 (
select top 1 with ties u.DepartamentId, sum(u.Salary) UsersSalarySum  from @users u
 group by u.DepartamentId
 order by UsersSalarySum desc
 )
 select p.* from @pc p
               join @Users u on p.id = u.PCId 
			    join @Departaments d on u.DepartamentId = d.id
  where d.id in (select DepartamentId from MaxSalaryByDepartments )


 